import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Video from './video.jsx'
import Text from './text.jsx'


ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/video" element={<Video />} />
        <Route path="/text" element={<Text />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>,
)
