import { Link } from "react-router-dom";
import "./App.css";

export default function Text() {
  return (
    <>
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Omingle | Chat</title>
        <link rel="stylesheet" href="css/style.css" />
      </head>

      <body>
        <header>
          <div className="logo">Omingle</div>

          <nav>
            <h4>
              <span id="connected">0</span> online right now
            </h4>
          </nav>
        </header>

        <div className="chat-container">
          <div className="right-section">
            <div className="message-area" id="message-area">
              <p>
                <span style={{ color: "lightblue" }}>you</span>: hello
              </p>
              <p>
                <span style={{ color: "lightcoral" }}>stranger</span>: hi
              </p>
            </div>
            <h4
              className="error"
              id="error"
              style={{ color: "#FF9494", paddingLeft: "10px" }}
            ></h4>
            <div className="input-area">
              <button className="next-button" style={{ marginRight: "5px" }}>
                Next (ESC)
              </button>
              <input
                type="text"
                className="chat-input"
                placeholder="type your message here"
              />
              <button className="send-button">Send</button>
            </div>
          </div>
        </div>

        <footer>
          <p>
            &copy; 2023 Omingle |{" "}
            <a href="https://discord.gg/" className="href">
              <img src="assets/discord.svg" alt="Discord" />
              Discord
            </a>
          </p>
        </footer>
      </body>
    </>
  );
}
