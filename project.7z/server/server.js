// Import required modules
const { WebSocket, WebSocketServer } = require('ws');
const http = require('http');
const uuidv4 = require('uuid').v4;

const server = http.createServer();
const wsServer = new WebSocketServer({ server });
const port = 8000;

server.listen(port, () => {
  console.log(`WebSocket server is running on port ${port}`);
});


const clients = {};
const users = {};
let editorContent = null;
let userActivity = [];

wsServer.on('connection', function handleNewConnection(connection) {
  const userId = uuidv4();
  console.log('Received a new connection');

  clients[userId] = connection;
  console.log(`${userId} connected.`);

  connection.on('message', (message) => processReceivedMessage(message, userId));
  connection.on('close', () => handleClientDisconnection(userId));
});

function processReceivedMessage(message, userId) {
    const dataFromClient = JSON.parse(message.toString());
    const json = { type: dataFromClient.type };
  
    if (dataFromClient.type === eventTypes.USER_EVENT) {
      users[userId] = dataFromClient;
      userActivity.push(`${dataFromClient.username} joined to collaborate`);
      json.data = { users, userActivity };
    } else if (dataFromClient.type === eventTypes.CONTENT_CHANGE) {
      editorContent = dataFromClient.content;
      json.data = { editorContent, userActivity };
    }
  
    sendMessageToAllClients(json);
  }